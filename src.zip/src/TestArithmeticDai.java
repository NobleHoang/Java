public class TestArithmeticDai {
    public static void main(String[] args){
        int number1, number2;
        int sum;
        number1 = 9;
        number2 = 36;
        sum = 36*number1 + 9*number2;
        System.out.println("The sum is: "+sum);
        System.out.println("Enter to OK");
    }
}
