public class MauJava {
    public static void main(String[] args) {}
}
