public class SevenCaculation {
    public static void main(String[] args){
        int number1= 11;
        int number2= 22;
        int number3= 33;
        int number4= 44;
        int number5= 55;
        int number6= 66;
        int number7= 77;
        int sum;
        sum = number1 + number2 + number3 + number4 + number5 + number6 + number7;
        System.out.print("The sum is: ");
        System.out.println(sum);
        System.out.println("Very Good!!!");
        System.out.println("Finish....");
    }
}
