public class ReTangleCompution {
    public static void main(String[] args){
        double length, width, area, perimeter;
        length = 6;
        width = 3;
        area = length*width;
        perimeter = (length+width)*2;
        System.out.print("The area is: ");
        System.out.println(area);
        System.out.print("The perimeter is: ");
        System.out.println(perimeter);
        System.out.println("Done");
    }
}
