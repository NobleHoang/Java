public class ex81 {
    public static void main(String[] args) {
        double length ,width , perimeter , acreage;
        length = 20;
        width = 10;
        perimeter = (length + width ) * 2;
        acreage = length * width;
        System.out.printf("perimeter is :");
        System.out.println(perimeter);
        System.out.printf("acreage is :");
        System.out.println(acreage);
    }
}

