public class PrintTest {
    public static void main(String[] args){
        System.out.println("Hello World!");
        System.out.println("Hello World Again!");
        System.out.println();
        System.out.print("Hello World!");
        System.out.print("Hello World Again!");
        System.out.println();
        System.out.print("Hello,");
        System.out.print(" ");
        System.out.println("world!");
        System.out.println("Hello, world!");
    }
}
