public class PrintSheepPattern {
    public static void main(String[] args){
        System.out.print("          ");
        System.out.println("'_'");
        System.out.print("          ");
        System.out.println("(oo)");
        System.out.print("  ");
        System.out.print("/");
        System.out.print("========");
        System.out.print("/");
        System.out.println("/");
        System.out.print(" ");
        System.out.print("/");
        System.out.print(" ");
        System.out.print("||");
        System.out.print(" ");
        System.out.print("@");
        System.out.print("@");
        System.out.print(" ");
        System.out.println("||");
        System.out.print("*");
        System.out.print("  ");
        System.out.print("||");
        System.out.print("----");
        System.out.println("||");
        System.out.print("   ");
        System.out.print("vv");
        System.out.print("    ");
        System.out.println("vv");
        System.out.print("   ");
        System.out.print("''");
        System.out.print("    ");
        System.out.println("''");
    }
}
