public class SaleProduct {
    public static void main(String[] args) {
        int sanpham1 = 11;
        int sanpham2 = 22;
        int sanpham3 = 33;
        int sanpham4 = 44;
        int sanpham5 = 55;
        int soluong1 = 1;
        int soluong2 = 2;
        int soluong3 = 3;
        int soluong4 = 4;
        int soluong5 = 6;
        int sum;
        sum = sanpham1 * soluong1 + sanpham2 * soluong2 + sanpham3 * soluong3 + sanpham4 * soluong4 + sanpham5 * soluong5;
        System.out.print("The sum is: ");
        System.out.println(sum);
        System.out.println("Very Good!!!");
        System.out.println("Finish....");
    }
}

