public class CircleCompution {
    public static void main(String[] args){
        double radius, area, circumperence;
        final double PI = 3.14159265;
        radius = 5;
        area = radius* radius* PI;
        circumperence = 2*radius*PI;
        System.out.print("The radius is: ");
        System.out.println(radius);
        System.out.print("The area is: ");
        System.out.println(area);
        System.out.print("The circumperence is: ");
        System.out.println(circumperence);
    }
}
