public class PrintStartPattern {
    public static void main(String[] args){
        System.out.println("      *");
        System.out.print("*  ");
        System.out.print("*  ");
        System.out.print("  *  ");
        System.out.println("*");
        System.out.print("    *  ");
        System.out.println("*");
        System.out.print("  *      ");
        System.out.println("*");
    }
}
