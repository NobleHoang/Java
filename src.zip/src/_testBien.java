public class _testBien {
    public static void main(String[] args){
        int number;
        number = 66;
        number = 88;
        number = number + 1;
        int sum = 0;
        sum = sum + number;
        int num1 = 3 , num2 = 6;
        double radius = 1.5;
        String mgs;
        mgs = "Hello";
        //int number;
        //sum = 55.55;
        //sum = "Helllo";
        System.out.print("The sum is: ");
        System.out.println(sum);
        System.out.println(mgs);
    }
}
