public class TestArithmeticBigBap {
    public static void main(String[] args){
        int number1, number2, number3;
        int sum, Multiplication;
        number1 = 33;
        number2 = 88;
        number3 = 66;
        sum = number1 + number2 + number3;
        Multiplication = number1*number2*number3;
        System.out.println("this sum of 3 number is : " +sum + " and Multiplication of 3 number is : "+Multiplication);
    }
}
